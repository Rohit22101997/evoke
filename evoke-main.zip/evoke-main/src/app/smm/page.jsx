import React from 'react'
import Footer from "@/components/Footer";
import Navbar from "@/components/Navbar";
import Herosmm from "@/components/Herosmm";
import Section3smm from "@/components/Section3smm";
import Section4smm from "@/components/Section4smm";
import Section6smm from "@/components/Section6smm";
import Section8smm from "@/components/Section8smm";
import Section10smm from "@/components/Section10smm";

export default function page() {
  return (
    <div>
    <Navbar/>
    <Herosmm />
    <Section3smm />
    <Section6smm />
    <Section8smm />
    <Section10smm />

     <Section4smm />

     
   
    

    <Footer/>
    </div>
  )
}
